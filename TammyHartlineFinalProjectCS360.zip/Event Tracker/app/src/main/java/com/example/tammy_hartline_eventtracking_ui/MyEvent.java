package com.example.tammy_hartline_eventtracking_ui;
import java.util.Calendar;

public class MyEvent {
    private int id;
    private String title;
    private Calendar date;
    private String description;
    private String eventUsername;

    public MyEvent() {
        // Default constructor
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Calendar getDate() {
        return date;
    }

    public void setDate(Calendar date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEventusername() {
        return eventUsername;
    }

    public void setEventusername(String eventUsername) {
        this.eventUsername = eventUsername;
    }
}
